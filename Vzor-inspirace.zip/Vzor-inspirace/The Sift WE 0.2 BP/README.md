# The Sift Add-On

The Sift Add-On recreates Minecraft's mysterious new dimension for Minecraft: Bedrock Edition. Travel beyond the Overworld and explore an endless realm of enormous floating islands, unusual forests, custom wildlife, and an atmosphere unlike any vanilla dimension.

The terrain is generated progressively as you explore, allowing The Sift to continue expanding in every direction.

## Features

### The Sift

A fully explorable custom dimension formed from vast floating islands. Its terrain includes plains, cliffs, valleys, and large mountain formations, all suspended over the void.

The dimension has its own fog, ambient particles, vegetation, terrain palette, and procedural generation system. New areas are generated while players travel through the world.

### Sift Forests

The islands contain large forests inspired by the trees shown during Minecraft Live. Sift trees have thick trunks, broad canopies, custom logs, and custom leaves that give the dimension its distinctive silhouette.

### Sift Wildlife

Sift Rabbits can appear naturally across the islands. They use custom visuals, behave like rabbits, and can be bred with carrots or golden carrots.

### New Blocks

The Add-On introduces a growing collection of blocks and vegetation used throughout the dimension, including:

- Sift Stone
- Sift Grass
- Light Sift Grass
- Short Sift Grass
- Sift Logs
- Sift Leaves
- The Sift Portal

Grass surfaces can appear in different orientations, while patches of light grass and short vegetation add variation across the landscape.

### The Sift Portal

The reinforced deepslate structure found in Ancient Cities can be activated as a portal to The Sift. The portal uses a custom animated texture, emits light, and transports players when they walk through it.

Portal frames are detected in either horizontal orientation, so the structure can face along the X or Z axis.

## Entering The Sift in Survival

1. Locate an Ancient City in the Deep Dark.
2. Find the large reinforced deepslate frame at the center of the city.
3. Remove the sculk and any other blocks obstructing the inside of the frame.
4. Use flint and steel to place fire on top of the reinforced deepslate at the bottom of the opening.
5. Wait for the interior to fill with the animated Sift Portal.
6. Walk into the portal to enter The Sift.

The portal supports rectangular reinforced deepslate frames with an interior between 2 and 21 blocks wide and between 3 and 21 blocks tall.

## Entering With Commands

You can enter The Sift directly by running:

```mcfunction
/the_sift:travel
```

Run the same command while inside The Sift to return to your previous dimension and location.

The portal block can also be obtained in Creative mode or with:

```mcfunction
/give @s the_sift:sift_portal
```

## Installation

Both packs are required:

- **The Sift BP** provides the dimension, world generation, entities, portal behavior, and scripts.
- **The Sift RP** provides models, textures, animations, fog, particles, and sounds.

Activate both packs in the same world before entering it. If you update the Add-On, close and reopen the world so Minecraft reloads its scripts and block definitions.

## Important Notes

- Terrain generates around players as they explore. A short delay may occur when entering a new area for the first time.
- Player-built structures are preserved after leaving the dimension or closing the world.
- The portal frame must have a complete reinforced deepslate base, two sides, and a top.
- Back up important worlds before installing or updating any Add-On that introduces custom dimensions.

## Compatibility

The Sift is designed for Minecraft: Bedrock Edition and requires both its Behavior Pack and Resource Pack. Java Edition is not supported.

## Development Status

The Add-On is under active development. Additional terrain features, blocks, vegetation, creatures, and structures may be introduced in future versions.
